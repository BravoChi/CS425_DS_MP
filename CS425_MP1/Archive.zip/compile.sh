#!/bin/sh
javac ServerInfo.java
javac ClientThread.java
javac Client.java
javac SysGrep.java
javac ServerThread.java
javac Server.java
java Server
